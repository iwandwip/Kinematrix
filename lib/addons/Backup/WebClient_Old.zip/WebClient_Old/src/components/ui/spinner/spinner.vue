<script setup lang="ts">

import {LoaderCircle} from "lucide-vue-next";
</script>

<template>
  <div class="fixed inset-0 flex justify-center items-center">
    <LoaderCircle class="animate-spin h-24 w-24 text-green-700" />
  </div>
</template>

<style scoped>

</style>