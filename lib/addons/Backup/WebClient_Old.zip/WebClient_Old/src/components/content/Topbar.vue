<script setup lang="ts">

</script>

<template>
  <nav class="hidden flex-col gap-6 text-lg font-medium md:flex md:flex-row md:items-center md:gap-5 md:text-sm lg:gap-6">
    <a
        href="#"
        class="flex items-center gap-2 text-lg font-semibold md:text-base"
    >
    </a>
    <a
        href="#"
        class="text-foreground transition-colors hover:text-foreground"
    >
      Dashboard
    </a>
    <a
        href="#"
        class="text-muted-foreground transition-colors hover:text-foreground"
    >
      Orders
    </a>
    <a
        href="#"
        class="text-muted-foreground transition-colors hover:text-foreground"
    >
      Products
    </a>
    <a
        href="#"
        class="text-muted-foreground transition-colors hover:text-foreground"
    >
      Customers
    </a>
    <a
        href="#"
        class="text-muted-foreground transition-colors hover:text-foreground"
    >
      Analytics
    </a>
  </nav>
</template>

<style scoped>

</style>