<script setup lang="ts">

import {Badge} from "@/components/ui/badge";
</script>

<template>
  <div class="ml-auto flex-1 sm:flex-initial">
    <h2
        class="scroll-m-20  pb-2 text-xl font-semibold tracking-tight transition-colors first:mt-0"
    >
      Auto Light System
      <Badge>v2.0</Badge>
    </h2>
  </div>
</template>

<style scoped>

</style>