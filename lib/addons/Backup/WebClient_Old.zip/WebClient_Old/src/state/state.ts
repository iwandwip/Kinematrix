import alsDataStateManagement from "@/state/store/als.ts";
import settingStateManagement from "@/state/store/settings.ts";


export const alsData = alsDataStateManagement();
export const settingsData = settingStateManagement();

