import axios from 'axios';

axios.defaults.baseURL = "http://192.168.4.1:8000/api/v1/data";