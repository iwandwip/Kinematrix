package com.als.v.dua.nol.workalogi;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
