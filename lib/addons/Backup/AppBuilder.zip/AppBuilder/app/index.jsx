import React from 'react';
import WebViewContainer from '../components/WebViewContainer';

export default function Index() {
  return <WebViewContainer />;
}