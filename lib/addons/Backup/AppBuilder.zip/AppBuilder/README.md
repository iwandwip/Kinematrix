# 025-025-Chris
Sistem Pengukur Tingkat Kelelahan Atlet Dengan Metode Fuzzy Sugeno Di Dojo Karate Akai
